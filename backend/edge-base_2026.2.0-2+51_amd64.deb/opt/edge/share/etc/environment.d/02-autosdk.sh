# Configuration of the edge-autosdk* package.
export VPW_MULTI_CONSTR=1

# Pick the newest OpenVINO directory that exists.
if [[ -d /opt/openvino-2025.0 ]]; then
  # d12, u24
  OPENVINO_LIB=/opt/openvino-2025.0/lib
elif [[ -d /opt/openvino-2023.0 ]]; then
  # d10
  OPENVINO_LIB=/opt/openvino-2023.0/lib
else
  # vm
  OPENVINO_LIB=""
fi

export LD_LIBRARY_PATH="${LD_LIBRARY_PATH:+$LD_LIBRARY_PATH:}/opt/autosdk/lib${OPENVINO_LIB:+:$OPENVINO_LIB}"
